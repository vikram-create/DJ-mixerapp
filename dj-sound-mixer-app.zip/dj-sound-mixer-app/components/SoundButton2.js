import * as React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import {Audio} from 'expo-av';

class SoundEyk extends React.Component {
   playSound = async () => {
    await Audio.Sound.createAsync(
      { uri: 'http://soundbible.com/grab.php?id=257&type=mp3' },
      { shouldPlay: true }
    );
  }

  render() {
    return (
      <TouchableOpacity
        style={styles.button}
        onPress={this.playSound}>
        <Text
          style={styles.buttonText}>
          Press Me
        </Text>
      </TouchableOpacity>
    );
  }
}
const styles = StyleSheet.create({
button: {
    marginTop: 0,
    marginLeft: 0,
    borderWidth: 5,
    borderColor: 'rgba(100,70,100,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    width: 140,
    height: 170,
    backgroundColor: 'yellow',
    borderRadius: 100,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 40,
  }
  
});

export default SoundEyk;