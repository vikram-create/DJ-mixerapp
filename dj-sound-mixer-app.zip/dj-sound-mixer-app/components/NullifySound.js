import * as React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import {Audio} from 'expo-av';

class NullifySound extends React.Component {
   playSound = async () => {
    await Audio.Sound.createAsync(
      { uri: 'null' },
      { shouldPlay: true }
    );
  }

  render() {
    return (
      <TouchableOpacity
        style={styles.button}
        onPress={this.playSound}>
        <Text
          style={styles.buttonText}>
          Silencer
        </Text>
      </TouchableOpacity>
    );
  }
}
const styles = StyleSheet.create({
button: {
    marginTop: 0,
    marginLeft: 100,
    borderWidth: 5,
    borderColor: 'rgba(100,70,100,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    width: 170,
    height: 170,
    backgroundColor: 'Black',
    borderRadius: 100,
  },
  buttonText: {
    fontWeight: 'bold',
    fontSize: 40,
  }
  
});

export default NullifySound;